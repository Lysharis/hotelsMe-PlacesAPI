<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App;
use App\Services\PayUService\Exception;

class HomeController extends Controller
{
    public function index(Request $request){
        
        // set IP address and API access key
        $ip = '41.39.140.3';
        $ipapi_key = '4ba10befb04e11b0454192851b79967b';
        $ipdata_key = 'ec669fd75557b7916a1aef8d05d298a6a71032d6d5e78068ba44f033';
        $ClientInfo ;
        if($request->ip() > 1){
            $ip = $request->ip();
        }
        try{
            $ipdata_response =  file_get_contents("https://api.ipdata.co/".$ip."?api-key=".$ipdata_key);
            $ipapi_response =  file_get_contents("http://api.ipapi.com/".$ip."?access_key=".$ipapi_key);
            foreach(json_decode($ipdata_response) as $key => $value){$ClientInfo[$key] = $value;}
            foreach(json_decode($ipapi_response) as $key => $value){$ClientInfo[$key] = $value;}
            $ClientInfo = json_decode(json_encode($ClientInfo),false) ;
            App::setLocale($ClientInfo->location->languages[0]->code);
            
            return view('map')->with(['ClientInfo' => $ClientInfo]);
        }
        catch (Exception $e){
            return $e->getMessage();
        }
    }
}
