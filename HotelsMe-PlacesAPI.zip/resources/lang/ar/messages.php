<?php

return [
    'Country' => 'الدولة',
    'Language' => 'اللغة',
    'Currency' => 'العملة',
    'Time Zone' => 'المنطقة الزمنية',
    'Current Time' => 'الوقت الحالى',
    'Search Box' => 'مربع البحث',
];