<?php

return [
    'Country' => 'Country',
    'Language' => 'Language',
    'Currency' => 'Currency',
    'Time Zone' => 'Time Zone',
    'Current Time' => 'Current Time',
    'Search Box' => 'Search Box',
];