<!DOCTYPE html>
<html>
    <head>
    
        <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
        <meta charset="utf-8">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <link rel="shortcut icon" sizes="196x196" href="https://hotelsme.com/assets/images/logo.svg">
        <link rel="apple-touch-icon" href="https://hotelsme.com/assets/images/logo.svg">
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        <?php if(isset($ClientInfo->languages[0]->rtl)): ?>
            <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-rtl/3.4.0/css/bootstrap-rtl.min.css" rel="stylesheet">
        <?php endif; ?>
        <title>Places Search Box</title>
        <style>
        
        html, body {height: 100%;margin: 0;padding: 0;}
        #description {font-family: Roboto;font-size: 15px;font-weight: 300;}
        #infowindow-content .title {font-weight: bold;}
        #infowindow-content {display: none;}
        #map #infowindow-content {display: inline;}
        .pac-card {margin: 10px 10px 0 0;border-radius: 2px 0 0 2px;box-sizing: border-box;-moz-box-sizing: border-box;outline: none;box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);background-color: #fff;font-family: Roboto;}
        #pac-container {padding-bottom: 12px;margin-right: 12px;}
        .pac-controls {display: inline-block;padding: 5px 11px;}
        .pac-controls label {font-family: Roboto;font-size: 13px;font-weight: 300;}
        #pac-input {
            background-color: #ffffff;
            border: 1px solid #f3f1f1;
            font-family: Roboto;
            width: calc(100% - 255px);
            box-shadow: 0px 1px 6px -3px #717171;
            color: #000000;
            line-height: 39px;
            font-size: 15px;
            font-weight: 300;
            padding: 0 11px 0 13px;
            text-overflow: ellipsis;
            margin: 10px auto;
        }
        #pac-input:focus {border-color: #00ff1f;}
        #title {color: #fff;background-color: #4d90fe;font-size: 25px;font-weight: 500;padding: 6px 12px;}
        #target {width: 345px;}
        .overlay{
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8);
            z-index: 1;
        }
        .client-info {
            height: 400px;
            width: 100%;
            margin-top: 15px;
            display: inline-block;
            color: white;
            border: 2px solid #00ff1f;
            box-shadow: 0px 0px 10px 0px #00ff1f;
            border-radius: 15px;
            text-align:center;
        }
        #map {    
            height: 400px;
            width: 100%;
            margin-top: 15px;
            border: 2px solid #00ff1f;
            box-shadow: 0px 0px 10px 0px #00ff1f;
            border-radius: 15px;
        }
        .Task_title{
            text-shadow: 0px 0px 15px #00ff1f;
            color: #00ff1f;
            text-decoration: underline;
        }
        .client-info .row div:first-child{
            color:#00ff1f;
            font-size:15px;
            font-family: monospace;
        }
        </style>
    </head>
    <body>
        <div class="overlay">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-3">
                        <div class="client-info">
                            <svg width="200px" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 366.4 126.7" enable-background="new 0 0 366.4 126.7" xml:space="preserve">
                                <g>
                                    <path fill="#00ff1f" d="M338.9,104.5c-4.2,2.3-8.2,3.4-11.8,3.4c-3.8,0-6.9-1.3-9-4c-1.5-1.8-2.2-4.4-2.2-7.5   c0-8.3,3.9-16.6,11.7-24.5c6.4-6.6,11.9-9.8,16.8-9.8c1.4,0,2.7,0.4,3.8,1.3c1.4,1.1,2.1,2.6,2.1,4.5c0,2.7-1.2,6-3.6,9.8   c-4.9,7.7-12.3,13.2-22,16.2v0.9c0,1,0.2,1.7,0.7,2.4c1.1,1.6,2.9,2.4,5.5,2.4c5.9,0,12.8-4.6,20.6-13.8c1.1-1.2,2.1-2,3-2.4   c2.3-6.2,3.5-13,3.5-20c0-17-7.3-32.3-18.9-43c-0.4,0.8-0.8,1.6-1.3,2.6c-0.4,0.7-2.4,4.3-6,10.5c-6.4,11.3-10.8,19.5-13,24.3   c-6.2,13.2-10.8,24.6-13.7,33.9c-1.7,5.5-2.5,9.6-2.5,12.1c0,0.6,0,1.2,0.1,1.7c0.3,2.6,0.4,3.2,0.4,3.4c0,1.6-0.6,3-1.7,4.3   c-1,1.2-2.2,1.9-3.6,1.9c-1.6,0-2.9-0.9-3.9-2.7c-0.8-1.3-1.2-3.1-1.2-5.4c0-13.2,10.7-38.9,31.7-76.5   c-11,12.5-23.1,29.6-36.1,50.9c-3.2,5.2-5.9,8.8-8,10.7c-2.1,1.9-4.2,2.8-6.2,2.8c-2.1,0-3.6-0.9-4.6-2.7c-0.6-1.1-0.9-2.5-0.9-4   c0-11.5,6.5-29.5,19.4-53.4c-3.7,4.1-7.3,8.8-10.8,13.9c-8.1,12.1-15.5,24.7-21.9,37.4c-1.3,2.6-2.7,5.7-4.3,9.1   c10.4,15.9,28.4,26.4,48.8,26.4c17.7,0,33.5-7.9,44.2-20.3C342.1,102.6,340.5,103.6,338.9,104.5"/>
                                    <path fill="#00ff1f" d="M281.4,31.1c5.9-7.4,10.1-12.3,12.4-14.6c4.1-4,6.9-4.6,9.6-2.1c1.2,1.1,1.9,2.5,1.9,3.9c0,1.6-1,4-3.1,7.5   c-5.8,9.4-11.2,20.1-16,31.9c-3.6,9.2-6.2,17.3-7.6,24.1c1.9-2.9,4.9-7.5,9.1-14c4.8-7.4,12.5-18.2,23-32.1   c6.1-8.1,11.7-14.9,16.6-20.4c0.7-0.8,1.4-1.4,2-2c-8.7-5.2-18.9-8.2-29.8-8.2c-32.2,0-58.3,26.1-58.3,58.3c0,8,1.6,15.5,4.5,22.5   C255.8,66.6,267.8,48.2,281.4,31.1"/>
                                    <path fill="#00ff1f" d="M341.2,74.6c0.7-1.1,1-2,1-2.8c0-0.7-0.3-0.9-0.8-0.9c-0.8,0-2.3,0.5-5,2.7c-3.8,3-7,7.4-9.6,13   c2.7-1,4.9-2.2,6.5-3.4C336.6,80.8,339.2,77.8,341.2,74.6"/>
                                    <path fill="#fff" d="M8.4,90h6.6c2.3,0,3.5,0.2,4.7,1.4c0.8,0.8,1.3,1.8,1.3,3.3c0,3.1-2.2,3.9-3.1,4.2c1.1,0.3,3.7,1.1,3.7,4.6   c0,2.5-1.6,3.8-2.2,4.2c-1.3,0.8-2.7,0.8-4.2,0.8H8.4V90z M10.9,97.9h3.6c0.9,0,3.9,0,3.9-2.9c0-2.8-2.3-2.8-3.8-2.8h-3.7V97.9z    M10.9,106.5h4.4c2,0,3.7-1.1,3.7-3.2c0-1.8-1.3-3.2-3.5-3.2h-4.5V106.5z"/>
                                    <path fill="#fff" d="M42.5,92c1.9-2.1,4.5-2.5,6.2-2.5c5.1,0,8.4,3.3,8.4,9.6c0,4.9-2,9.9-8.6,9.9c-6.3,0-8.4-4.5-8.4-9.6   C40.1,97.3,40.5,94.2,42.5,92 M44.5,105.2c1.1,1.3,2.6,1.7,4.1,1.7c1.5,0,3-0.4,4.1-1.7c1.5-1.9,1.7-4.8,1.7-6   c0-4.2-1.4-7.4-5.6-7.4c-4.7,0-5.9,3.8-5.9,7.6C42.8,101.3,43.2,103.6,44.5,105.2"/>
                                    <path fill="#fff" d="M78,92c1.9-2.1,4.5-2.5,6.2-2.5c5.1,0,8.4,3.3,8.4,9.6c0,4.9-2,9.9-8.6,9.9c-6.3,0-8.4-4.5-8.4-9.6   C75.6,97.3,75.9,94.2,78,92 M79.9,105.2c1.1,1.3,2.6,1.7,4.1,1.7c1.5,0,3-0.4,4.1-1.7c1.5-1.9,1.7-4.8,1.7-6c0-4.2-1.4-7.4-5.6-7.4   c-4.7,0-5.9,3.8-5.9,7.6C78.3,101.3,78.7,103.6,79.9,105.2"/>
                                    <polygon fill="#fff" points="111.9,90 114.5,90 114.5,98.2 122.2,90 125.8,90 117.4,98.3 126.7,108.6 123.1,108.6 114.5,98.8    114.5,108.6 111.9,108.6  "/>
                                    <rect x="144.4" y="90" fill="#fff" width="2.6" height="18.6"/>
                                    <polygon fill="#fff" points="167.2,90 170.8,90 179.9,105.4 179.9,90 182.3,90 182.3,108.6 179,108.6 169.6,92.8 169.6,108.6    167.2,108.6  "/>
                                    <path fill="#fff" d="M215.1,94.7c-0.3-1.7-1.7-2.9-4.2-2.9c-1.8,0-3.2,0.5-4.2,1.6c-1.6,1.8-2,4.2-2,6c0,1.6,0.3,4.2,1.7,5.8   c1.2,1.4,3.1,1.8,4.9,1.8c2.1,0,3.4-0.4,4-0.6v-5.5h-4.2v-2.1h6.8v9.2c-1.1,0.4-3.4,1.1-6.6,1.1c-3.4,0-5.4-1-6.7-2.3   c-1.8-1.9-2.6-4.4-2.6-7.1c0-1.9,0.5-6.2,4-8.6c1.8-1.2,4.2-1.3,5.2-1.3c1.5,0,3.7,0.2,5.5,2c1.1,1.2,1.2,2.2,1.2,3H215.1z"/>
                                    <path fill="#00ff1f" d="M193.2,70.4c3.1,1.8,7,2.7,11.5,2.7c9.7,0,15.9-5.1,15.9-12.9c0-6.1-3.3-9.9-11.1-12.9   c-5.2-2-7.5-3.4-7.5-6.5c0-3,2.6-5.1,6.4-5.1c3.6,0,6.3,1.2,7.8,2.1c0,0,1.1,0.5,1.4-0.8l1.4-4.2c0.4-0.9-0.3-1.3-0.3-1.3   c-2.8-1.6-6.4-2.5-10.1-2.5c-8.7,0-14.7,5.2-14.7,12.6c0,5.3,3.9,9.5,11.2,12.2c5.4,2,7.3,3.8,7.3,7.1c0,3.5-2.8,5.6-7.5,5.6   c-3.6,0-7-1.2-9.2-2.7c0,0-1-0.5-1.4,0.6l-1.4,4.3C192.8,68.7,192.5,69.8,193.2,70.4"/>
                                    <path fill="#00ff1f" d="M51,17.6h-5.1c-0.9,0-1.6,0.7-1.6,1.6V40H16.6V19.1c0-0.9-0.7-1.6-1.6-1.6H10c-0.9,0-1.6,0.7-1.6,1.6v51.7   c0,0.9,0.7,1.6,1.6,1.6h5.1c0.9,0,1.6-0.7,1.6-1.6v-23h27.7v23c0,0.9,0.7,1.6,1.6,1.6H51c0.9,0,1.6-0.7,1.6-1.6V19.1   C52.6,18.3,51.9,17.6,51,17.6"/>
                                    <path fill="#00ff1f" d="M80.3,27.6c-13.7,0-19.9,11.6-19.9,22.4c0,10.8,6.2,22.4,19.9,22.4c13.7,0,19.9-11.6,19.9-22.4   C100.2,39.2,93.9,27.6,80.3,27.6 M80.3,65c-9.2,0-11.7-9.8-11.7-15c0-5.2,2.4-15,11.7-15C89.5,35,92,44.8,92,50   C92,55.2,89.5,65,80.3,65"/>
                                    <path fill="#00ff1f" d="M126.2,64.6c-1.1,0.4-2.5,0.4-3.6,0.4c-1.3,0-2.3-0.3-3-0.9c-0.6-0.6-0.9-1.7-0.9-3.1V41h7.4   c0.9,0,1.6-0.7,1.6-1.6v-4.3c0-0.9-0.7-1.6-1.6-1.6h-7.4V19.1c0-0.5-0.3-1-0.7-1.3c-0.4-0.3-1-0.3-1.5-0.1l-4.7,2   c-0.6,0.2-0.9,0.8-0.9,1.4v12.5h-6.3c-0.9,0-1.6,0.7-1.6,1.6v4.3c0,0.9,0.7,1.6,1.6,1.6h6.3l0,18.9c0,3.3,0,7.1,2.6,9.7   c1.8,1.8,4.6,2.7,8.4,2.7c1.9,0,3.9-0.4,5.2-0.8c0.7-0.2,1.2-0.8,1.2-1.5V66c0-0.5-0.2-1-0.6-1.3C127.2,64.5,126.6,64.4,126.2,64.6   "/>
                                    <path fill="#00ff1f" d="M151.1,27.6C138,27.6,132,39.2,132,50c0,11.1,5.8,22.4,18.8,22.4c10.4,0,16.7-4.9,19.3-14.9   c0.1-0.5,0-1-0.3-1.3c-0.3-0.4-0.7-0.6-1.2-0.6h-4.9c-0.7,0-1.4,0.5-1.5,1.2c-1,4.8-5.1,8.2-9.8,8.2c-9.3,0-11.6-7.1-12-12.3h28.7   c0.9,0,1.6-0.7,1.6-1.6C170.6,35.9,163.7,27.6,151.1,27.6 M140.6,45.2c0.9-5,4.1-10.2,10.6-10.2c8.1,0,10.4,6.2,11,10.2H140.6z"/>
                                    <path fill="#00ff1f" d="M184,17.6h-4.7c-0.9,0-1.6,0.7-1.6,1.6v51.7c0,0.9,0.7,1.6,1.6,1.6h4.7c0.9,0,1.6-0.7,1.6-1.6V19.1   C185.6,18.3,184.9,17.6,184,17.6"/>
                                </g>
                            </svg>
                            <h3 class="Task_title">HotelsMe-PlacesAPI Test</h3>
                            <hr style="background-color:#00ff1f;">
                            <div class="row">
                                <div class="col"><?php echo e(__('IP')); ?></div>
                                <div class="col"><?php echo e($ClientInfo->ip); ?></div>
                            </div>
                            <div class="row">
                                <div class="col"><?php echo e(__('messages.Country')); ?></div>
                                <div class="col"><?php echo e($ClientInfo->country_name); ?> <img width="20" src="<?php echo e($ClientInfo->location->country_flag); ?>" alt=""> </div>
                            </div>
                            <div class="row">
                                <div class="col"><?php echo e(__('messages.Language')); ?></div>
                                <div class="col"><?php echo e($ClientInfo->location->languages[0]->native); ?> (<?php echo e($ClientInfo->location->languages[0]->code); ?>)</div>
                            </div>
                            <div class="row">
                                <div class="col"><?php echo e(__('messages.Currency')); ?></div>
                                <div class="col"><?php echo e($ClientInfo->currency->name); ?> (<?php echo e($ClientInfo->currency->native); ?>)</div>
                            </div>
                            <div class="row">
                                <div class="col"><?php echo e(__('messages.Time Zone')); ?></div>
                                <div class="col"><?php echo e($ClientInfo->time_zone->name); ?></div>
                            </div>

                        </div>
                    </div>
                    <div class="col-md-9">
                        <div id="map"></div>
                        <input id="pac-input" class="controls" type="text" placeholder="<?php echo e(__('messages.Search Box')); ?>">
                    </div>
                </div>
                
            </div>
        </div>
    </body>
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script>

        var position = {
            lat : <?php echo e($ClientInfo->latitude); ?>,
            lng : <?php echo e($ClientInfo->longitude); ?>,
        }
        function initAutocomplete() {
            var map = new google.maps.Map(document.getElementById('map'), {
                center: position,
                zoom: 18,
                mapTypeId: 'roadmap',
            });
            map

            var marker = new google.maps.Marker({
                position: position,
                map: map,
                title: '<?php echo e($ClientInfo->ip); ?>'
            });
            setInterval(function(){
                if (navigator.geolocation) {
                    navigator.geolocation.getCurrentPosition(function(position) {
                        position = {
                            lat: position.coords.latitude,
                            lng: position.coords.longitude
                        };
                        map.setCenter(position);
                        marker.setPosition(position);
                    });
                } else {
                    console.log('Browser doesn\'t support Geolocation');
                }
                // alert('eshtat');
            }, 3000);
            
            // Create the search box and link it to the UI element.
            var input = document.getElementById('pac-input');
            var searchBox = new google.maps.places.SearchBox(input);
            map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

            // Bias the SearchBox results towards current map's viewport.
            map.addListener('bounds_changed', function() {
                searchBox.setBounds(map.getBounds());
            });

            var markers = [];
            // Listen for the event fired when the user selects a prediction and retrieve
            // more details for that place.
            searchBox.addListener('places_changed', function() {

                var places = searchBox.getPlaces();
                if (places.length == 0) {
                    return;
                }

                // Clear out the old markers.
                markers.forEach(function(marker) {
                    marker.setMap(null);
                });
                markers = [];

                // For each place, get the icon, name and location.
                var bounds = new google.maps.LatLngBounds();

                places.forEach(function(place) {
                    if (!place.geometry) {
                        console.log("Returned place contains no geometry");
                        return;
                    }
                    var icon = {
                        url: place.icon,
                        size: new google.maps.Size(71, 71),
                        origin: new google.maps.Point(0, 0),
                        anchor: new google.maps.Point(17, 34),
                        scaledSize: new google.maps.Size(25, 25)
                    };

                    // Create a marker for each place.
                    markers.push(new google.maps.Marker({
                        map: map,
                        icon: icon,
                        title: place.name,
                        position: place.geometry.location
                    }));

                    if (place.geometry.viewport) {
                        // Only geocodes have viewport.
                        bounds.union(place.geometry.viewport);
                    } else {
                        bounds.extend(place.geometry.location);
                    }
                });

                map.fitBounds(bounds);

            });
        }
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD_hPSr9IEUvl2zy0hVifLbtilLBO9FQR0&language=<?php echo e($ClientInfo->location->languages[0]->code); ?>&libraries=places&callback=initAutocomplete" async defer></script>
</html>
